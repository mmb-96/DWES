package initparam;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MultipleBienvenidaServlet
 */
@WebServlet(
		urlPatterns = { "/SaludosDelServlet" }, 
		initParams = { 
				@WebInitParam(name = "mensaje", value = "Saludos desde el Servlet"), 
				@WebInitParam(name = "veces", value = "5", description = "Repeticiones del mensaje")
		})
public class MultipleBienvenidaServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MultipleBienvenidaServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		ServletContext application = request.getServletContext();
		ServletConfig config = this.getServletConfig();
		ServletOutputStream out = response.getOutputStream();
		int veces = Integer.parseInt(config.getInitParameter("veces"));
		String mensaje = config.getInitParameter("mensaje");
				
		out.println("<html>");
		out.println("<head>");
		out.println("<title>Bienvenido al servlet</title>");
		out.println("</head>");
		out.println("<body>");
		out.println("Datos<br>");
		out.println("<b>Contexto de aplicación:</b><br>");
		out.println("Nombre de la aplicación: "+application.getInitParameter("nombreAp")+"<br>");
		out.println("<b>Contexto de servlet:</b><br>");
		out.println("El mensaje <b>"+mensaje+"</b> se va a repetir <b>"+veces+"</b> veces <br>");
		for (int i=1;i<=veces;i++)
			out.println(mensaje+"<br>");
		out.println("</body>");
		out.println("</html>");
		
	}

}
