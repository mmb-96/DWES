package beans;

import java.io.*;
import java.util.*;

/**
 * Encapsula los datos de registro de un usuario, consistente en un nombre 
 * de usuario (equivale al concepto de login) y una clave. Implementa la interfaz 
 * Serializable con objeto de que pueda almacenarse el estado a través del 
 * contenedor web.
 */
@SuppressWarnings("serial")
public class DatosRegistro implements Serializable
{

  /**
   * Contiene el nombre de usuario. Tiene la función de login.
   */
  private String nombre = "ninguno";
  
  /**
   * Clave empleada por el usuario para acceder a servicios.
   */
  private String clave = "ninguna";
  
  public DatosRegistro()
  {
  }
  
  
  /**
   * Obtiene el valor de la propiedad nombre.
   * @return Cadena con el nombre de usuario.
   */
  public String getNombre() 
  {
    return nombre;
  }
  /**
   * Establece el valor de la propiedad nombre.
   * @param nombre  El nombre del usuario.
   */
  public void setNombre (String nombre) 
  {
    this.nombre = nombre;
  }
  /**
   * Obtiene el valor de la propiedad clave.
   * @return La clave del usuario.
   */
  public String getClave() 
  {
    return clave;
  }
  /**
   * Establece el valor de la propiedad clave.
   * @param clave Clave de usuario.
   */
  public void setClave(String clave) 
  {
    this.clave = clave;
  }
  /**
   * Comprueba si el nombre de usuario almacenado en la propiedad nombre 
   * está ya almacenada en el archivo /home/alumno/login.dat. Este archivo
   * sólo contiene logins (nombre de usuario). Está serializado mediante
   * un array de String.
   * @return true Si existe ya ese nombre de usuario.
   * @return false Si no se ha encontrado.
   */
  public boolean getExisteLogin() 
  {
          ArrayList<String> listaLogin = null;
          ObjectInputStream ois = null;
          File archivoLogin = new File ("/home/frolik/login.dat");
          if (archivoLogin.exists()) {
            try {
              ois = new ObjectInputStream(new FileInputStream(archivoLogin));
              listaLogin = (ArrayList<String>) ois.readObject();
              for (int i = 0; i<listaLogin.size(); i++) {
                if (listaLogin.get(i).equalsIgnoreCase(nombre)) {
                  return true;
                }
              }
            }
            catch (Exception e)  //Dada cualquier excepción
            {
              return false;
            }
            finally {
            	try {
					ois.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            }
          }
        return false;          
  }
  
  /**
   * Añade un nombre de usuario al archivo
   * de login. No hace uso de la variable nombre.
   * @param login Nombre que se añadirá al archivo.
   */
  @SuppressWarnings("unchecked")
public void setAddLogin(String login)
  {
    ArrayList<String> listaLogin;

    ObjectOutputStream oos = null;
    ObjectInputStream ois = null;  
    
    File archivoLogin = new File ("/home/frolik/login.dat");
    try 
    {
      if (archivoLogin.exists()) {
        ois = new ObjectInputStream(new FileInputStream(archivoLogin));
        listaLogin = (ArrayList<String>) ois.readObject();
      }
      else
      {
        listaLogin = new ArrayList<String>();       
      }
      listaLogin.add(login);
      oos = new ObjectOutputStream(new FileOutputStream(archivoLogin));
      oos.writeObject(listaLogin); 
    }
          
    catch (FileNotFoundException fne)
    {
      System.out.println("Error, archivo no encontrado.");
    }
    catch (ClassNotFoundException cnfe)
    {
      System.out.println("Error, clase no encontrada al leer archivo de login.");
    }
    catch (IOException ioe)
    {
      System.out.println("Error de E/S en proceso setAddLogin()");
    }
    finally {
    	try {
			oos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
  }
  /**
   * Devuelve un array de dos String conteniendo el primer elemento el valor
   * de la propiedad nombre y el segundo el valor de la propiedad clave.
   * @return Array de dos cadenas con nombre y clave respectivamente.
   */
  public String[] estado() 
  {
    String[] estado = new String[2];
    estado[0] = nombre;
    estado[1] = clave;
    return estado;
  }

}
