/**
 *
 * @author Eduardo A. Ponce
 * @version 1.0
 */

package fotogramas.util;

import java.io.*;

public class CargaFotograma {
    private String archivoFotogramas;

    public CargaFotograma() {
        archivoFotogramas = "/home/frolik/fotogramas.txt";
    }

    public String leeFotograma() {
        String fotograma;
        try
        {
            // Crear un objeto File que referenciará a un archivo
            File archivo = new File(archivoFotogramas);
            // Se crea un flujo orientado a leer caracteres desde un archivo
            FileReader fr = new FileReader(archivo);
            // Se encadena con un flujo orientado a cadenas de caracteres
            BufferedReader br = new BufferedReader (fr);
            // Se lee una cadena del archivo, que termina en un fin de línea.
            fotograma = br.readLine();
            
        }
        catch(FileNotFoundException fnfe)
        {
            // Excepción que lanza FileReader cuando no encuentra el archivo
            fotograma = "No se ha encontrado el archivo";
        }
        catch (IOException ioe)
        {
            // Excepción que lanza el método readLine() cuando tiene problemas para leer de la fuente de datos
            fotograma =  "Error al leer del archivo.";
        }
        catch (Exception exp) {
            fotograma = "No encontrado";
        }
        return fotograma;
    }

}
