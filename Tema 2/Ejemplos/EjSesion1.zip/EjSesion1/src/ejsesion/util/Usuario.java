package ejsesion.util;
import javax.servlet.http.HttpSession;
import java.util.*;

public class Usuario 
{
  String idUsuario;
  String idSesion;
  HttpSession sesion;
  Date fecha;
  public Usuario(String idUsuario, HttpSession sesion)
  {
    this.idUsuario = idUsuario;
    this.idSesion = sesion.getId();
    this.sesion = sesion;
    this.fecha = new Date();
  }

  public void setIdUsuario(String idUsuario)
  {
    this.idUsuario = idUsuario;
  }


  public String getIdUsuario()
  {
    return idUsuario;
  }


  public void setIdSesion(String idSesion)
  {
    this.idSesion = idSesion;
  }


  public String getIdSesion()
  {
    return idSesion;
  }


  public void setSesion(HttpSession sesion)
  {
    this.sesion = sesion;
  }


  public HttpSession getSesion()
  {
    return sesion;
  }


  public void setFecha(Date fecha)
  {
    this.fecha = fecha;
  }


  public Date getFecha()
  {
    return fecha;
  }
}

