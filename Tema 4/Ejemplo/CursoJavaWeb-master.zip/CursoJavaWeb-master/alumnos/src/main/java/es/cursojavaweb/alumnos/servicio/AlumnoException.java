package es.cursojavaweb.alumnos.servicio;

public class AlumnoException extends RuntimeException {

    /**
     * 
     */
    private static final long serialVersionUID = 7917425177634591315L;

    public AlumnoException(String msg) {
        super(msg);
    }
}
